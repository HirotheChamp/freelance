package com.javanewprojectcopy.javanewprojectcopy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavanewprojectcopyApplicationTests {

	@Test
	void contextLoads() {
	}

}
